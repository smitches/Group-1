Steps to run the code:
1. Open the "group_1_assignment5.pde" file.
2. Click "Run" to display the animation.