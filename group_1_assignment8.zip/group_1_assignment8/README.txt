Part 1: run the PDE file
move the two sliders to choose hair color and male/female

Part 2: Option 1: run the PDE file and click "RANDOM" to get three different cities
Option 2: choose specifically which Assignment for city and search criteria. 
	You search by typing into the box by pressing Backspace/Delete and then digit keys. Then "Search"

Part 3: run the pde file
choose which section you would like to read about with the radio buttons
hover over titles to see description
click next/previous button for new list of titles in same category
click title to open webpage