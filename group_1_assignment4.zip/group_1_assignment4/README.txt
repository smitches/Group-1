Steps to run the code:
1. Open the "group_1_assignment4.pde" file.
2. Click "Tools" on the Processing Tool Bar
3. Then click on "Add Tool…"
4. Then click on the Libraries tab
5. Search and click on "Sound | Sound Library based on MethCla for Processing"
6. click Install to install Sound in Processing
7. Exit "Contribution Manager"
8. Click "Run" to display the animation.